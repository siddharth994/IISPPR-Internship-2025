# Internship at International Institute of SDGs & Public Policy Research (IISPPR)

This repository documents my internship experience as a **Research Intern** at the  
**International Institute of SDGs & Public Policy Research (IISPPR)** from **May 19, 2025 – July 3, 2025**.

---

## 📌 Internship Overview
- **Role:** Research Intern (Part-time)  
- **Duration:** May 19, 2025 – July 3, 2025  
- **Domain:** Public Policy & Cultural Diplomacy  
- **Institute:** International Institute of SDGs & Public Policy Research (IISPPR)  
- **Work Mode:** Remote/Hybrid  

---

## 🎯 Key Contributions
- Conducted research on **India’s cultural diplomacy and soft power strategy**.  
- Authored a paper titled:  
  *"Projecting Culture, Shaping Perceptions: India’s Use of Cultural Diplomacy in Global Engagement"*.  
- Article successfully **published** by IISPPR in July 2025.  
- Explored themes such as **yoga diplomacy, Bollywood, diaspora, art, literature, education, and international case studies**.  

---

## 🏆 Achievements
- Received **Internship Certificate** from IISPPR.  
- Received **Publication Certificate** for successful research contribution.  

Certificates are available in the [Certificates](./Certificates) folder.

---

## 📂 Repository Contents
- **Certificates/** → Internship and Publication certificates.  
- **Research/** → Project document and markdown version for easy access.  
- **Extras/** → Additional notes and summary of learnings.  

---

## 🔍 About IISPPR
The **International Institute of SDGs & Public Policy Research (IISPPR)** is a research-driven organization working on **policy, sustainability, and global governance** with a focus on **SDGs, international relations, and cultural diplomacy**.  

🌐 [Website](http://iisppr.org.in) | ✉️ manager@iisppr.in  

---
