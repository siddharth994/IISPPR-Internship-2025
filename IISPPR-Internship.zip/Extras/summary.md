# Internship Summary & Learnings

During my internship at **IISPPR**, I worked on cultural diplomacy and its role in shaping India’s global engagement.  

### Key Learnings:
- Importance of **soft power** in international relations.  
- How **yoga, cinema, cuisine, literature, and diaspora** strengthen India’s cultural diplomacy.  
- Research methodology: combining **literature review, case studies, and policy analysis**.  
- Experience of contributing to a **published research paper** during the internship.  

This internship enhanced my understanding of **policy research, global diplomacy, and academic writing**.
